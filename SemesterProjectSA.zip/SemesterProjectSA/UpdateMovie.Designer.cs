﻿namespace SemesterProjectSA
{
    partial class UpdateMovie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdateFind = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUpdateMovieTitle = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUpdateYear = new System.Windows.Forms.TextBox();
            this.txtUpdateDirector = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUpdateRottenTomatoesScore = new System.Windows.Forms.TextBox();
            this.txtUpdateBoxOfficeEarnings = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnUpdateClear = new System.Windows.Forms.Button();
            this.btnUpdateClose = new System.Windows.Forms.Button();
            this.comboBoxUpdateGenre = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnUpdateFind
            // 
            this.btnUpdateFind.Location = new System.Drawing.Point(525, 54);
            this.btnUpdateFind.Name = "btnUpdateFind";
            this.btnUpdateFind.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateFind.TabIndex = 1;
            this.btnUpdateFind.Text = "Find";
            this.btnUpdateFind.UseVisualStyleBackColor = true;
            this.btnUpdateFind.Click += new System.EventHandler(this.btnUpdateFind_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Movie Title:";
            // 
            // txtUpdateMovieTitle
            // 
            this.txtUpdateMovieTitle.Location = new System.Drawing.Point(107, 56);
            this.txtUpdateMovieTitle.Name = "txtUpdateMovieTitle";
            this.txtUpdateMovieTitle.Size = new System.Drawing.Size(412, 20);
            this.txtUpdateMovieTitle.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Year:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Director:";
            // 
            // txtUpdateYear
            // 
            this.txtUpdateYear.Location = new System.Drawing.Point(107, 105);
            this.txtUpdateYear.Name = "txtUpdateYear";
            this.txtUpdateYear.Size = new System.Drawing.Size(83, 20);
            this.txtUpdateYear.TabIndex = 2;
            // 
            // txtUpdateDirector
            // 
            this.txtUpdateDirector.Location = new System.Drawing.Point(107, 164);
            this.txtUpdateDirector.Name = "txtUpdateDirector";
            this.txtUpdateDirector.Size = new System.Drawing.Size(186, 20);
            this.txtUpdateDirector.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 231);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Genre:";
            // 
            // txtUpdateRottenTomatoesScore
            // 
            this.txtUpdateRottenTomatoesScore.Location = new System.Drawing.Point(236, 319);
            this.txtUpdateRottenTomatoesScore.Name = "txtUpdateRottenTomatoesScore";
            this.txtUpdateRottenTomatoesScore.Size = new System.Drawing.Size(69, 20);
            this.txtUpdateRottenTomatoesScore.TabIndex = 5;
            // 
            // txtUpdateBoxOfficeEarnings
            // 
            this.txtUpdateBoxOfficeEarnings.Location = new System.Drawing.Point(471, 322);
            this.txtUpdateBoxOfficeEarnings.Name = "txtUpdateBoxOfficeEarnings";
            this.txtUpdateBoxOfficeEarnings.Size = new System.Drawing.Size(129, 20);
            this.txtUpdateBoxOfficeEarnings.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(104, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Rotten Tomatoes Score:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(362, 326);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Box Office Earnings:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(42, 398);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnUpdateClear
            // 
            this.btnUpdateClear.Location = new System.Drawing.Point(178, 398);
            this.btnUpdateClear.Name = "btnUpdateClear";
            this.btnUpdateClear.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateClear.TabIndex = 8;
            this.btnUpdateClear.Text = "Clear";
            this.btnUpdateClear.UseVisualStyleBackColor = true;
            this.btnUpdateClear.Click += new System.EventHandler(this.btnUpdateClear_Click);
            // 
            // btnUpdateClose
            // 
            this.btnUpdateClose.Location = new System.Drawing.Point(684, 398);
            this.btnUpdateClose.Name = "btnUpdateClose";
            this.btnUpdateClose.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateClose.TabIndex = 9;
            this.btnUpdateClose.Text = "Close";
            this.btnUpdateClose.UseVisualStyleBackColor = true;
            this.btnUpdateClose.Click += new System.EventHandler(this.btnUpdateClose_Click);
            // 
            // comboBoxUpdateGenre
            // 
            this.comboBoxUpdateGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUpdateGenre.FormattingEnabled = true;
            this.comboBoxUpdateGenre.Items.AddRange(new object[] {
            "Animation",
            "Action",
            "Comedy",
            "Drama",
            "Horror ",
            "Mystery",
            "Romance",
            "Science Fiction",
            "Western"});
            this.comboBoxUpdateGenre.Location = new System.Drawing.Point(107, 223);
            this.comboBoxUpdateGenre.Name = "comboBoxUpdateGenre";
            this.comboBoxUpdateGenre.Size = new System.Drawing.Size(186, 21);
            this.comboBoxUpdateGenre.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(13, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(185, 22);
            this.label7.TabIndex = 16;
            this.label7.Text = "Update Movie Screen";
            // 
            // UpdateMovie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxUpdateGenre);
            this.Controls.Add(this.btnUpdateClose);
            this.Controls.Add(this.btnUpdateClear);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtUpdateBoxOfficeEarnings);
            this.Controls.Add(this.txtUpdateRottenTomatoesScore);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtUpdateDirector);
            this.Controls.Add(this.txtUpdateYear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUpdateMovieTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUpdateFind);
            this.Name = "UpdateMovie";
            this.Text = "Update Movie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateFind;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUpdateMovieTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUpdateYear;
        private System.Windows.Forms.TextBox txtUpdateDirector;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUpdateRottenTomatoesScore;
        private System.Windows.Forms.TextBox txtUpdateBoxOfficeEarnings;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnUpdateClear;
        private System.Windows.Forms.Button btnUpdateClose;
        private System.Windows.Forms.ComboBox comboBoxUpdateGenre;
        private System.Windows.Forms.Label label7;
    }
}