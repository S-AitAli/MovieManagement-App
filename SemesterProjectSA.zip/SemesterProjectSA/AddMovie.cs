﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemesterProjectSA
{
    public partial class AddMovie : Form
    {
        public AddMovie()
        {
            InitializeComponent();

        }

        // Code the Close button.
        private void btnAddClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Retrive user's input, validate user's input, instantiate a new class, pass the class to the insertMovie () method.

        string[] movieGenre = { "Animation", "Action", "Comedy", "Drama", "Horror", "Mystery", "Romance", "Science Fiction", "Western" };
        private void btnAdd_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = { txtAddMovieTitle, txtAddYear, txtAddDirector, txtAddRottenTomattoesScore, txtAddBoxOfficeEarnings };
            foreach (var textbox in textBoxes) { textbox.BackColor = Color.White; }
            comboBoxAddGenre.BackColor = Color.White;

            if (txtAddMovieTitle.Text == "")
            {
                MessageBox.Show("The Title can't be empty", "Input Left Empty");
                txtAddMovieTitle.BackColor = Color.PaleVioletRed;
                txtAddMovieTitle.Focus();
                return;
            }


            bool isValid = int.TryParse(txtAddYear.Text, out int Year);
            if (txtAddYear.Text == "")
            {
                MessageBox.Show("The Year can't be empty", "Input Left Empty");
                txtAddYear.BackColor = Color.PaleVioletRed; ;
                txtAddYear.Focus();
                return;
            }
            else if ((!isValid) || Year <= 0) {
                MessageBox.Show("Please enter a valid year", "Invalid Input");
                txtAddYear.BackColor = Color.PaleVioletRed;
                txtAddYear.Focus();
                return;
            }

            if (txtAddDirector.Text == "")
            {
                MessageBox.Show("The Director can't be empty", "Input Left Empty");
                txtAddDirector.BackColor = Color.PaleVioletRed; ;
                txtAddDirector.Focus();
                return;
            }
            else if (!Regex.IsMatch(txtAddDirector.Text, "^[a-zA-Z ]+$"))
            {
                MessageBox.Show("Please enter a valid director name", "Invalid Input");
                txtAddDirector.BackColor = Color.PaleVioletRed;
                txtAddDirector.Focus();
                return;
            }

            if (comboBoxAddGenre.Text == "")
            {
                MessageBox.Show("The Genre can't be empty", "Input Left Empty");
                comboBoxAddGenre.BackColor = Color.PaleVioletRed;
                comboBoxAddGenre.Focus();
                return;
            }


            isValid = int.TryParse(txtAddRottenTomattoesScore.Text, out int RottenTomattoesScore);
            if (txtAddRottenTomattoesScore.Text == "")
            {
                MessageBox.Show("Please enter Rotten Tomatoes Score for this movie.", "Input Left Empty");
                txtAddRottenTomattoesScore.BackColor = Color.PaleVioletRed; ;
                txtAddRottenTomattoesScore.Focus();
                return;
            }
            else if ((!isValid) || RottenTomattoesScore < 0 || RottenTomattoesScore > 100)
            {
                MessageBox.Show("Please enter a valid Rotten Tomatoes Score between 0 and 100", "Invalid Input");
                txtAddRottenTomattoesScore.BackColor = Color.PaleVioletRed;
                txtAddRottenTomattoesScore.Focus();
                return;
            }

            isValid = decimal.TryParse(txtAddBoxOfficeEarnings.Text, out decimal BoxOfficeEarnings);
            if (txtAddBoxOfficeEarnings.Text == "")
            {
                MessageBox.Show("Please enter the Total Earned for this movie.", "Input Left Empty");
                txtAddBoxOfficeEarnings.BackColor = Color.PaleVioletRed; ;
                txtAddBoxOfficeEarnings.Focus();
                return;
            }
            else if ((!isValid) || BoxOfficeEarnings < 0)
            {
                MessageBox.Show("Please enter a valid decimal", "Invalid Input");
                txtAddBoxOfficeEarnings.BackColor = Color.PaleVioletRed;
                txtAddBoxOfficeEarnings.Focus();
                return;
            }

            Movie movieAdded = new Movie();
            movieAdded.Title = txtAddMovieTitle.Text;
            movieAdded.Year = Year;
            movieAdded.Director = txtAddDirector.Text;
            movieAdded.Genre = comboBoxAddGenre.Text;
            movieAdded.RottenTomatoesScore = RottenTomattoesScore;
            movieAdded.TotalEarned = BoxOfficeEarnings;


            insertMovie(movieAdded);

            txtAddMovieTitle.Text = "";
            txtAddYear.Text = "";
            txtAddDirector.Text = "";
            comboBoxAddGenre.Text = "";
            txtAddRottenTomattoesScore.Text = "";
            txtAddBoxOfficeEarnings.Text = "";

        }

        public int insertMovie(Movie movie)
        {
            string connectionString = Main.GetConnectionString();

            try
            {

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM dbo.Movies WHERE Title = @Title", connection))
                {
                    command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = movie.Title;
                    connection.Open();
                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show($"You cannot add {movie.Title} because it already exists in the database.", "Cannot add");
                        return 0;
                    }
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand("INSERT INTO dbo.Movies (Title, Year, Director, Genre, RottenTomatoesScore, TotalEarned)" +
                   "VALUES(@Title, @Year, @Director, @Genre, @RottenTomatoesScore, @TotalEarned)", connection))
                {

                    command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = movie.Title;
                    command.Parameters.Add("Year", SqlDbType.Int).Value = movie.Year;
                    command.Parameters.Add("Director", SqlDbType.VarChar, 50).Value = movie.Director;
                    command.Parameters.Add("Genre", SqlDbType.Int).Value = (Array.IndexOf(movieGenre, movie.Genre) + 1);

                    // Handle nulls
                    object dbRottenTomatoesScore = movie.RottenTomatoesScore;
                    if (dbRottenTomatoesScore == null)
                    {
                        dbRottenTomatoesScore = DBNull.Value;
                    }
                    command.Parameters.Add("RottenTomatoesScore", SqlDbType.Int).Value = dbRottenTomatoesScore;

                    object dbTotalEarned = movie.TotalEarned;
                    if (dbTotalEarned == null)
                    {
                        dbTotalEarned = DBNull.Value;
                    }
                    command.Parameters.Add("TotalEarned", SqlDbType.Decimal, 14).Value = movie.TotalEarned;

                    connection.Open();
                    MessageBox.Show("New Movie has been added to the Movies database", "Success");
                    return command.ExecuteNonQuery();


                }

            }
            catch (Exception ex)
            {
                // Handle the exception 
                MessageBox.Show($"An error occurred while adding the movie: {ex.Message}", "Error");
                return 0;
            }
        }
        private void btnAddClear_Click(object sender, EventArgs e)
        {
            txtAddMovieTitle.Text = "";
            txtAddYear.Text = "";
            txtAddDirector.Text = "";
            comboBoxAddGenre.Text = "";
            txtAddRottenTomattoesScore.Text = "";
            txtAddBoxOfficeEarnings.Text = "";
        }
    }
}
