﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemesterProjectSA
{
    public partial class DeleteMovie : Form
    {
        public DeleteMovie()
        {
            InitializeComponent();
        }

        private void btnDeleteClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDeleteClear_Click(object sender, EventArgs e)
        {
            txtDeleteMovieTitle.Text = "";
            txtDeleteYear.Text = "";
            txtDeleteDirector.Text = "";
            comboBoxDeleteGenre.Text = "";
            txtDeleteRottenTomatoesScore.Text = "";
            txtDeleteOfficeEarning.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = { txtDeleteMovieTitle, txtDeleteYear, txtDeleteDirector, txtDeleteRottenTomatoesScore, txtDeleteOfficeEarning };
            foreach (var textbox in textBoxes) { textbox.BackColor = Color.White; }
            comboBoxDeleteGenre.BackColor= Color.White;

            if (txtDeleteMovieTitle.Text == "")
            {
                MessageBox.Show("There is no movies entered to Delete! Please enter Movie Title and click the Find button! ", "Input Left Empty");
                txtDeleteMovieTitle.BackColor = Color.PaleVioletRed;
                txtDeleteMovieTitle.Focus();
                return;
            }

           
            Movie movieToRemove = new Movie();

            movieToRemove.Title = txtDeleteMovieTitle.Text;

            DialogResult result = MessageBox.Show("Are you sure you want to Delete movie? ", "Delete Confirmation", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                RemoveMovie(movieToRemove);

                MessageBox.Show($"Movie {movieToRemove.Title} has been deleted from Movies database", "Success");
            }

            txtDeleteMovieTitle.Text = "";
            txtDeleteYear.Text = "";
            txtDeleteDirector.Text = "";
            comboBoxDeleteGenre.Text = "";
            txtDeleteRottenTomatoesScore.Text = "";
            txtDeleteOfficeEarning.Text = "";

        }

        public int RemoveMovie(Movie movie)
        {
            string connectionString = Main.GetConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand("DELETE FROM Movies WHERE Title = @Title", connection))
                {
                    command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = movie.Title;

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }catch(Exception ex) {
                MessageBox.Show($"An error occurred while Deleting the movie: {ex.Message}", "Error");
                return 0;
            }
        }

        // Code the Find Button

        private void GetMovieByTitle()
        {
            string connectionString = Main.GetConnectionString();
            List<Movie> movies = new List<Movie>();
            string sqlCommand = "SELECT * FROM  Movies WHERE Title = @Title";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = txtDeleteMovieTitle.Text;
                        connection.Open();
                        object result = command.ExecuteScalar();

                        if (result == null)
                        {
                            MessageBox.Show("No Movie Found. Please try again.");
                        }
                        else
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    txtDeleteYear.Text = (reader["Year"].ToString());
                                    txtDeleteDirector.Text = (reader["Director"].ToString());

                                    switch (reader["Genre"].ToString())
                                    {
                                        case ("1"):
                                            comboBoxDeleteGenre.Text = "Animation";
                                            break;

                                        case ("2"):
                                            comboBoxDeleteGenre.Text = "Action";
                                            break;

                                        case ("3"):
                                            comboBoxDeleteGenre.Text = "Comedy";
                                            break;

                                        case ("4"):
                                            comboBoxDeleteGenre.Text = "Drama";
                                            break;
                                        case ("5"):
                                            comboBoxDeleteGenre.Text = "Horror";
                                            break;

                                        case ("6"):
                                            comboBoxDeleteGenre.Text = "Mystery";
                                            break;
                                        case ("7"):
                                            comboBoxDeleteGenre.Text = "Romance";
                                            break;
                                        case ("8"):
                                            comboBoxDeleteGenre.Text = "Science Fiction";
                                            break;
                                        case ("9"):
                                            comboBoxDeleteGenre.Text = "Western";
                                            break;



                                    }


                                    if (reader["RottenTomatoesScore"] == DBNull.Value)
                                    {
                                        txtDeleteRottenTomatoesScore.Text = "";
                                    }
                                    else
                                        txtDeleteRottenTomatoesScore.Text = (reader["RottenTomatoesScore"].ToString());
                                    if (reader["TotalEarned"] == DBNull.Value)
                                    {
                                        txtDeleteOfficeEarning.Text = "";
                                    }
                                    else
                                        txtDeleteOfficeEarning.Text = (reader["TotalEarned"].ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnDeleteFind_Click(object sender, EventArgs e)
        {
            string movieText = txtDeleteMovieTitle.Text;
            if (movieText == "")
            {
                MessageBox.Show("Movie title is required", "Invalid Input");
                txtDeleteMovieTitle.BackColor = Color.PaleVioletRed;
                txtDeleteMovieTitle.Focus();
                return;
            }

            GetMovieByTitle();
        }
    
    }
}
