﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemesterProjectSA
{
    public partial class UpdateMovie : Form
    {
        public UpdateMovie()
        {
            InitializeComponent();
        }

        private void btnUpdateClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdateClear_Click(object sender, EventArgs e)
        {
            txtUpdateMovieTitle.Text = "";
            txtUpdateYear.Text = "";
            txtUpdateDirector.Text = "";
            comboBoxUpdateGenre.Text = "";
            txtUpdateRottenTomatoesScore.Text = "";
            txtUpdateBoxOfficeEarnings.Text = "";
        }

        private void btnUpdateFind_Click(object sender, EventArgs e)
        {

            string movieText = txtUpdateMovieTitle.Text;
            if (movieText == "")
            {
                MessageBox.Show("Movie title is required", "Invalid Input");
                txtUpdateMovieTitle.BackColor = Color.PaleVioletRed;
                txtUpdateMovieTitle.Focus();
                return;
            }

            GetMovieByTitle();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxes = { txtUpdateMovieTitle, txtUpdateYear, txtUpdateDirector, txtUpdateRottenTomatoesScore, txtUpdateBoxOfficeEarnings };
            foreach (var textbox in textBoxes) { textbox.BackColor = Color.White; }
            comboBoxUpdateGenre.BackColor= Color.White;

            // Validate and retrive user's input to update a movie.
            if (txtUpdateMovieTitle.Text == "")
            {
                MessageBox.Show("There is no movies entered to update! Please enter Movie Title and click the Find button", "Input Left Empty");
                txtUpdateMovieTitle.BackColor = Color.PaleVioletRed;
                txtUpdateMovieTitle.Focus();
                return;
            }

            bool isValid = int.TryParse(txtUpdateYear.Text, out int Year);
            if ((!isValid) || Year <= 0)
            {
                MessageBox.Show("Please enter a valid year", "Invalid Input");
                txtUpdateYear.BackColor = Color.PaleVioletRed;
                txtUpdateYear.Focus();
                return;
            }

            if (txtUpdateDirector.Text == "")
            {
                MessageBox.Show("The Director can't be empty", "Input Left Empty");
                txtUpdateDirector.BackColor = Color.PaleVioletRed; ;
                txtUpdateDirector.Focus();
                return;
            }
            else if (!Regex.IsMatch(txtUpdateDirector.Text, "^[a-zA-Z ]+$"))
            {
                MessageBox.Show("Please enter a valid director name", "Invalid Input");
                txtUpdateDirector.BackColor = Color.PaleVioletRed;
                txtUpdateDirector.Focus();
                return;
            }

            isValid = int.TryParse(txtUpdateRottenTomatoesScore.Text, out int RottenTomattoesScore);
            if (txtUpdateRottenTomatoesScore.Text == "")
            {
                MessageBox.Show("Please enter Rotten Tomatoes Score for this movie.", "Input Left Empty");
                txtUpdateRottenTomatoesScore.BackColor = Color.PaleVioletRed; ;
                txtUpdateRottenTomatoesScore.Focus();
                return;
            }
            else if ((!isValid) || RottenTomattoesScore < 0 || RottenTomattoesScore > 100)
            {
                MessageBox.Show("Please enter a valid Rotten Tomatoes Score between 0 and 100", "Invalid Input");
                txtUpdateRottenTomatoesScore.BackColor = Color.PaleVioletRed;
                txtUpdateRottenTomatoesScore.Focus();
                return;
            }

            isValid = decimal.TryParse(txtUpdateBoxOfficeEarnings.Text, out decimal BoxOfficeEarnings);
            if (txtUpdateBoxOfficeEarnings.Text == "")
            {
                MessageBox.Show("Please enter the Total Earned for this movie.", "Input Left Empty");
                txtUpdateBoxOfficeEarnings.BackColor = Color.PaleVioletRed; ;
                txtUpdateBoxOfficeEarnings.Focus();
                return;
            }
            else if (!(isValid) || BoxOfficeEarnings < 0)
            {
                MessageBox.Show("Please enter a valid decimal", "Invalid Input");
                txtUpdateBoxOfficeEarnings.BackColor = Color.PaleVioletRed;
                txtUpdateBoxOfficeEarnings.Focus();
                return;
            }


            Movie movieToUpdate = new Movie();
            movieToUpdate.Title = txtUpdateMovieTitle.Text;
            movieToUpdate.Year = Year;
            movieToUpdate.Director = txtUpdateDirector.Text;
            movieToUpdate.Genre = comboBoxUpdateGenre.Text;
            movieToUpdate.RottenTomatoesScore = RottenTomattoesScore;
            movieToUpdate.TotalEarned = BoxOfficeEarnings;

            MovieUpdate(movieToUpdate);

            MessageBox.Show("Movie has been updated in the Movies database.", "Success");

            txtUpdateMovieTitle.Text = "";
            txtUpdateYear.Text = "";
            txtUpdateDirector.Text = "";
            comboBoxUpdateGenre.Text = "";
            txtUpdateRottenTomatoesScore.Text = "";
            txtUpdateBoxOfficeEarnings.Text = "";
        }

        string[] movieGenre = { "Animation", "Action", "Comedy", "Drama", "Horror", "Mystery", "Romance", "Science Fiction", "Western" };

        // MovieUpdate() method that updates movie's information.
        public int MovieUpdate(Movie movie)
        {
            string connectionString = Main.GetConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand("UPDATE dbo.Movies "
                    + "SET Title = @Title,"
                    + " Year = @Year,"
                    + " Director = @Director,"
                    + " Genre = @Genre,"
                    + " RottenTomatoesScore = @RottenTomatoesScore,"
                    + "TotalEarned = @TotalEarned WHERE Title = @Title", connection))

                {

                    command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = movie.Title;
                    command.Parameters.Add("Year", SqlDbType.Int).Value = movie.Year;
                    command.Parameters.Add("Director", SqlDbType.VarChar, 50).Value = movie.Director;
                    command.Parameters.Add("Genre", SqlDbType.Int).Value = (Array.IndexOf(movieGenre, movie.Genre) + 1);

                    object dbRottenTomatoesScore = movie.RottenTomatoesScore;
                    if (dbRottenTomatoesScore == null)
                    {
                        dbRottenTomatoesScore = DBNull.Value;
                    }
                    command.Parameters.Add("RottenTomatoesScore", SqlDbType.Int).Value = dbRottenTomatoesScore;

                    object dbTotalEarned = movie.TotalEarned;
                    if (dbTotalEarned == null)
                    {
                        dbTotalEarned = DBNull.Value;
                    }
                    command.Parameters.Add("TotalEarned", SqlDbType.Decimal, 14).Value = dbTotalEarned;

                    connection.Open();

                    return command.ExecuteNonQuery();
                }
            }catch(Exception ex) {
                MessageBox.Show($"An error occurred while Updating the movie: {ex.Message}", "Error");
                return 0;
            }
        }

        // Code the GetMovieByTitle() method for the Find button. 
        private void GetMovieByTitle()
        {
            string connectionString = Main.GetConnectionString();
            List<Movie> movies = new List<Movie>();
            string sqlCommand = "SELECT * FROM  Movies WHERE Title = @Title";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = txtUpdateMovieTitle.Text;
                        connection.Open();
                        object result = command.ExecuteScalar();

                        if (result == null)
                        {
                            MessageBox.Show("No Movie Found. Please try again.");
                        }
                        else
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    txtUpdateYear.Text = (reader["Year"].ToString());
                                    txtUpdateDirector.Text = (reader["Director"].ToString());

                                    switch (reader["Genre"].ToString())
                                    {
                                        case ("1"):
                                            comboBoxUpdateGenre.Text = "Animation";
                                            break;

                                        case ("2"):
                                            comboBoxUpdateGenre.Text = "Action";
                                            break;

                                        case ("3"):
                                            comboBoxUpdateGenre.Text = "Comedy";
                                            break;

                                        case ("4"):
                                            comboBoxUpdateGenre.Text = "Drama";
                                            break;
                                        case ("5"):
                                            comboBoxUpdateGenre.Text = "Horror";
                                            break;

                                        case ("6"):
                                            comboBoxUpdateGenre.Text = "Mystery";
                                            break;
                                        case ("7"):
                                            comboBoxUpdateGenre.Text = "Romance";
                                            break;
                                        case ("8"):
                                            comboBoxUpdateGenre.Text = "Science Fiction";
                                            break;
                                        case ("9"):
                                            comboBoxUpdateGenre.Text = "Western";
                                            break;



                                    }


                                    if (reader["RottenTomatoesScore"] == DBNull.Value)
                                    {
                                        txtUpdateRottenTomatoesScore.Text = "";
                                    }
                                    else
                                        txtUpdateRottenTomatoesScore.Text = (reader["RottenTomatoesScore"].ToString());
                                    if (reader["TotalEarned"] == DBNull.Value)
                                    {
                                        txtUpdateBoxOfficeEarnings.Text = "";
                                    }
                                    else
                                        txtUpdateBoxOfficeEarnings.Text = (reader["TotalEarned"].ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}

   


