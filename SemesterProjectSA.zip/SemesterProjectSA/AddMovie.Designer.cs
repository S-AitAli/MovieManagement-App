﻿namespace SemesterProjectSA
{
    partial class AddMovie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnAddClear = new System.Windows.Forms.Button();
            this.btnAddClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAddMovieTitle = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAddYear = new System.Windows.Forms.TextBox();
            this.txtAddDirector = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAddRottenTomattoesScore = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAddBoxOfficeEarnings = new System.Windows.Forms.TextBox();
            this.comboBoxAddGenre = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(44, 386);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnAddClear
            // 
            this.btnAddClear.Location = new System.Drawing.Point(172, 386);
            this.btnAddClear.Name = "btnAddClear";
            this.btnAddClear.Size = new System.Drawing.Size(75, 23);
            this.btnAddClear.TabIndex = 7;
            this.btnAddClear.Text = "Clear";
            this.btnAddClear.UseVisualStyleBackColor = true;
            this.btnAddClear.Click += new System.EventHandler(this.btnAddClear_Click);
            // 
            // btnAddClose
            // 
            this.btnAddClose.Location = new System.Drawing.Point(682, 386);
            this.btnAddClose.Name = "btnAddClose";
            this.btnAddClose.Size = new System.Drawing.Size(75, 23);
            this.btnAddClose.TabIndex = 8;
            this.btnAddClose.Text = "Close";
            this.btnAddClose.UseVisualStyleBackColor = true;
            this.btnAddClose.Click += new System.EventHandler(this.btnAddClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Movie Title:";
            // 
            // txtAddMovieTitle
            // 
            this.txtAddMovieTitle.Location = new System.Drawing.Point(120, 56);
            this.txtAddMovieTitle.Name = "txtAddMovieTitle";
            this.txtAddMovieTitle.Size = new System.Drawing.Size(367, 20);
            this.txtAddMovieTitle.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Year:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 262);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Genre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Director:";
            // 
            // txtAddYear
            // 
            this.txtAddYear.Location = new System.Drawing.Point(120, 117);
            this.txtAddYear.Name = "txtAddYear";
            this.txtAddYear.Size = new System.Drawing.Size(100, 20);
            this.txtAddYear.TabIndex = 1;
            // 
            // txtAddDirector
            // 
            this.txtAddDirector.Location = new System.Drawing.Point(120, 191);
            this.txtAddDirector.Name = "txtAddDirector";
            this.txtAddDirector.Size = new System.Drawing.Size(192, 20);
            this.txtAddDirector.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(117, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Rotten Tomatoes Score:";
            // 
            // txtAddRottenTomattoesScore
            // 
            this.txtAddRottenTomattoesScore.Location = new System.Drawing.Point(249, 310);
            this.txtAddRottenTomattoesScore.Name = "txtAddRottenTomattoesScore";
            this.txtAddRottenTomattoesScore.Size = new System.Drawing.Size(66, 20);
            this.txtAddRottenTomattoesScore.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(358, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Box Office Earnings:";
            // 
            // txtAddBoxOfficeEarnings
            // 
            this.txtAddBoxOfficeEarnings.Location = new System.Drawing.Point(467, 314);
            this.txtAddBoxOfficeEarnings.Name = "txtAddBoxOfficeEarnings";
            this.txtAddBoxOfficeEarnings.Size = new System.Drawing.Size(127, 20);
            this.txtAddBoxOfficeEarnings.TabIndex = 5;
            // 
            // comboBoxAddGenre
            // 
            this.comboBoxAddGenre.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.comboBoxAddGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAddGenre.FormattingEnabled = true;
            this.comboBoxAddGenre.Items.AddRange(new object[] {
            "Animation",
            "Action",
            "Comedy",
            "Drama",
            "Horror ",
            "Mystery",
            "Romance",
            "Science Fiction",
            "Western"});
            this.comboBoxAddGenre.Location = new System.Drawing.Point(122, 259);
            this.comboBoxAddGenre.Name = "comboBoxAddGenre";
            this.comboBoxAddGenre.Size = new System.Drawing.Size(190, 21);
            this.comboBoxAddGenre.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(12, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(160, 22);
            this.label7.TabIndex = 15;
            this.label7.Text = "Add Movie Screen";
            // 
            // AddMovie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxAddGenre);
            this.Controls.Add(this.txtAddBoxOfficeEarnings);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAddRottenTomattoesScore);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAddDirector);
            this.Controls.Add(this.txtAddYear);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAddMovieTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddClose);
            this.Controls.Add(this.btnAddClear);
            this.Controls.Add(this.btnAdd);
            this.Name = "AddMovie";
            this.Text = "Add Movie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnAddClear;
        private System.Windows.Forms.Button btnAddClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAddMovieTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAddYear;
        private System.Windows.Forms.TextBox txtAddDirector;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAddRottenTomattoesScore;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAddBoxOfficeEarnings;
        private System.Windows.Forms.ComboBox comboBoxAddGenre;
        private System.Windows.Forms.Label label7;
    }
}