﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemesterProjectSA
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();

            string title = "Movie Manager Application";
            richTextBoxAbout.SelectionFont = new Font("Times New Roman", 14, FontStyle.Bold);
            richTextBoxAbout.SelectionColor = Color.Blue;
            richTextBoxAbout.AppendText(title + "\n");

            string description = "This application reads data from a Microsoft SQL Server database. Further, it provides the typical CRUD operations: Create, Read, Update, and Delete" +
                " against the Movies table in our database.";
                
            richTextBoxAbout.SelectionFont = new Font("Times New Roman", 12, FontStyle.Regular);
            richTextBoxAbout.SelectionColor = Color.Black;
            richTextBoxAbout.AppendText("\n" + description + "\n");

            string coordinates = "Author:\tSara Ait Ali\nDate:\t\t05/03/2023\nVersion:\t1.0";
            richTextBoxAbout.SelectionFont = new Font("Times New Roman", 12, FontStyle.Bold);
            richTextBoxAbout.SelectionColor = Color.Black;
            richTextBoxAbout.AppendText("\n" + coordinates);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
