﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SemesterProjectSA
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        private void Main_Load(object sender, EventArgs e)
        {

            /*
             *Sara Ait Ali 04/03/2023.
             *
             * Develop a windows application written using Windows Forms that is capable of obtaining basic information from
             * a SQL server database related to movies that are entered into a database.
             * Further, there is the ability to add, update, and delete exsisting movies in the database.
             */

            readMovies();

           dgvMovies.Columns["TotalEarned"].DefaultCellStyle.Format = "C";

        }

        //Construct a connectin string, read data from the database, and populate the Data Grid View.
        //Call the readMovies() in the main load and the refresh button.

        private void readMovies()
        {
            string connectionString = GetConnectionString();


            List<Movie> movies = new List<Movie>();

            string sqlCommand = "SELECT Id, Title, Year, Director, Genre, RottenTomatoesScore, TotalEarned FROM Movies ORDER BY Title ";

            string[] movieGenre = { "Animation", "Action", "Comedy", "Drama", "Horror", "Mystery", "Romance", "Science Fiction", "Western" };


            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var movie = new Movie();
                                movie.Id = reader.GetInt32(0);
                                movie.Title = reader.GetString(1);
                                movie.Year = reader.GetInt32(2);
                                movie.Director = reader.GetString(3);


                                if (!reader.IsDBNull(4))
                                {
                                    int genreNumber = reader.GetInt32(4);
                                    movie.Genre = movieGenre[genreNumber - 1];
                                }

                                if (!reader.IsDBNull(5))
                                {
                                    movie.RottenTomatoesScore = reader.GetInt32(5);
                                }

                                if (!reader.IsDBNull(6))
                                {
                                    movie.TotalEarned = reader.GetDecimal(6);
                                }

                                movies.Add(movie);
                            }
                        }
                        connection.Close();
                       
                        dgvMovies.DataSource = movies;
                    }

                }
            }
            catch (Exception ex)

            {
                MessageBox.Show($"Something went wrong while opening a connection to the database: {ex.Message}");
            }
        }
        

        // GetConnectionString() method
        internal static string GetConnectionString()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            builder.DataSource = @"coursemaster1.csbchotp6tva.us-east-2.rds.amazonaws.com,1433";
            builder.InitialCatalog = "CSCI1630";
            builder.UserID = "rw1630";
            builder.Password = "Project!";


            return builder.ConnectionString;
        }

       

        // Invoke the About Form from the main menu
        private void mnuAbout_Click(object sender, EventArgs e)
        {
            About aboutForm = new About();
            aboutForm.ShowDialog(); 
        }

        // Code the Exit button that will close the app from the main menu.
        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Invoke the Add Movie form from the main menu.
        private void mnuAddMovie_Click(object sender, EventArgs e)
        {
            AddMovie addMovieForm = new AddMovie();
            addMovieForm.ShowDialog();
        }

        //Invoke the Update Movie form from the main menu.
        private void mnuUpdateMovie_Click(object sender, EventArgs e)
        {
            UpdateMovie updateMovieForm= new UpdateMovie();
            updateMovieForm.ShowDialog();   
        }

        // Invoke the Delete Movie form from the main menu.
        private void mnuDeleteMovie_Click(object sender, EventArgs e)
        {
            DeleteMovie deleteMovieForm = new DeleteMovie();
            deleteMovieForm.ShowDialog();
        }

        // Add code for Refresh menu item to populate Data Grid View on Demand.
        private void mnuRefreshList_Click(object sender, EventArgs e)
        {

            readMovies();
           dgvMovies.Columns["TotalEarned"].DefaultCellStyle.Format = "C";
        }
    }
}

