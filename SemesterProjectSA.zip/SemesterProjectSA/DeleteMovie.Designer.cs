﻿namespace SemesterProjectSA
{
    partial class DeleteMovie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeleteClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnDeleteClose = new System.Windows.Forms.Button();
            this.btnDeleteFind = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDeleteMovieTitle = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDeleteYear = new System.Windows.Forms.TextBox();
            this.txtDeleteDirector = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDeleteRottenTomatoesScore = new System.Windows.Forms.TextBox();
            this.txtDeleteOfficeEarning = new System.Windows.Forms.TextBox();
            this.comboBoxDeleteGenre = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDeleteClear
            // 
            this.btnDeleteClear.Location = new System.Drawing.Point(180, 407);
            this.btnDeleteClear.Name = "btnDeleteClear";
            this.btnDeleteClear.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteClear.TabIndex = 8;
            this.btnDeleteClear.Text = "Clear";
            this.btnDeleteClear.UseVisualStyleBackColor = true;
            this.btnDeleteClear.Click += new System.EventHandler(this.btnDeleteClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(27, 407);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnDeleteClose
            // 
            this.btnDeleteClose.Location = new System.Drawing.Point(690, 407);
            this.btnDeleteClose.Name = "btnDeleteClose";
            this.btnDeleteClose.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteClose.TabIndex = 9;
            this.btnDeleteClose.Text = "Close";
            this.btnDeleteClose.UseVisualStyleBackColor = true;
            this.btnDeleteClose.Click += new System.EventHandler(this.btnDeleteClose_Click);
            // 
            // btnDeleteFind
            // 
            this.btnDeleteFind.Location = new System.Drawing.Point(505, 61);
            this.btnDeleteFind.Name = "btnDeleteFind";
            this.btnDeleteFind.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteFind.TabIndex = 1;
            this.btnDeleteFind.Text = "Find";
            this.btnDeleteFind.UseVisualStyleBackColor = true;
            this.btnDeleteFind.Click += new System.EventHandler(this.btnDeleteFind_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Movie Title:";
            // 
            // txtDeleteMovieTitle
            // 
            this.txtDeleteMovieTitle.Location = new System.Drawing.Point(138, 64);
            this.txtDeleteMovieTitle.Name = "txtDeleteMovieTitle";
            this.txtDeleteMovieTitle.Size = new System.Drawing.Size(361, 20);
            this.txtDeleteMovieTitle.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Director:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Year:";
            // 
            // txtDeleteYear
            // 
            this.txtDeleteYear.Location = new System.Drawing.Point(138, 124);
            this.txtDeleteYear.Name = "txtDeleteYear";
            this.txtDeleteYear.Size = new System.Drawing.Size(100, 20);
            this.txtDeleteYear.TabIndex = 2;
            // 
            // txtDeleteDirector
            // 
            this.txtDeleteDirector.Location = new System.Drawing.Point(138, 173);
            this.txtDeleteDirector.Name = "txtDeleteDirector";
            this.txtDeleteDirector.Size = new System.Drawing.Size(169, 20);
            this.txtDeleteDirector.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(98, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Genre:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(98, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Rotten Tomatoes Score:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(376, 329);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Box Office Earning:";
            // 
            // txtDeleteRottenTomatoesScore
            // 
            this.txtDeleteRottenTomatoesScore.Location = new System.Drawing.Point(241, 322);
            this.txtDeleteRottenTomatoesScore.Name = "txtDeleteRottenTomatoesScore";
            this.txtDeleteRottenTomatoesScore.Size = new System.Drawing.Size(66, 20);
            this.txtDeleteRottenTomatoesScore.TabIndex = 5;
            // 
            // txtDeleteOfficeEarning
            // 
            this.txtDeleteOfficeEarning.Location = new System.Drawing.Point(480, 326);
            this.txtDeleteOfficeEarning.Name = "txtDeleteOfficeEarning";
            this.txtDeleteOfficeEarning.Size = new System.Drawing.Size(100, 20);
            this.txtDeleteOfficeEarning.TabIndex = 6;
            // 
            // comboBoxDeleteGenre
            // 
            this.comboBoxDeleteGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDeleteGenre.FormattingEnabled = true;
            this.comboBoxDeleteGenre.Items.AddRange(new object[] {
            "Animation",
            "Action",
            "Comedy",
            "Drama",
            "Horror ",
            "Mystery",
            "Romance",
            "Science Fiction",
            "Western"});
            this.comboBoxDeleteGenre.Location = new System.Drawing.Point(138, 230);
            this.comboBoxDeleteGenre.Name = "comboBoxDeleteGenre";
            this.comboBoxDeleteGenre.Size = new System.Drawing.Size(169, 21);
            this.comboBoxDeleteGenre.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(12, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(179, 22);
            this.label7.TabIndex = 16;
            this.label7.Text = "Delete Movie Screen";
            // 
            // DeleteMovie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 451);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxDeleteGenre);
            this.Controls.Add(this.txtDeleteOfficeEarning);
            this.Controls.Add(this.txtDeleteRottenTomatoesScore);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtDeleteDirector);
            this.Controls.Add(this.txtDeleteYear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDeleteMovieTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDeleteFind);
            this.Controls.Add(this.btnDeleteClose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnDeleteClear);
            this.Name = "DeleteMovie";
            this.Text = "Delete Movie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDeleteClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnDeleteClose;
        private System.Windows.Forms.Button btnDeleteFind;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDeleteMovieTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDeleteYear;
        private System.Windows.Forms.TextBox txtDeleteDirector;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDeleteRottenTomatoesScore;
        private System.Windows.Forms.TextBox txtDeleteOfficeEarning;
        private System.Windows.Forms.ComboBox comboBoxDeleteGenre;
        private System.Windows.Forms.Label label7;
    }
}